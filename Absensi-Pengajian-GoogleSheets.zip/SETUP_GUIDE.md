# PANDUAN SETUP — Daftar Hadir Pengajian (Database Google Spreadsheet)

Panduan ini ditulis untuk pengguna awam. Ikuti langkah bernomor secara berurutan.
Total waktu: ± 15–20 menit.

Alur besar:
```
Google Drive → Google Spreadsheet → Apps Script → Code.gs → Index.html
→ setupInitialData() → Authorization → Deploy Web App → Web App URL
→ Testing → QR Code → Absensi → Google Spreadsheet
```

---

## BAGIAN A — MEMBUAT GOOGLE SPREADSHEET (DATABASE)

1. Buka **https://drive.google.com** dan login dengan akun Google Anda.
2. Klik **+ New (Baru)** → **Google Sheets** → **Blank spreadsheet**.
3. Ganti nama spreadsheet di kiri atas menjadi, misalnya: `Database Absensi Pengajian`.
4. Biarkan spreadsheet ini kosong — sheet dan kolom akan **dibuat otomatis oleh sistem** pada Bagian C.

---

## BAGIAN B — MEMBUAT PROJECT APPS SCRIPT

1. Masih di dalam spreadsheet yang baru dibuat, klik menu **Extensions (Ekstensi)** → **Apps Script**.
   Ini akan membuka tab baru berisi editor kode, dan project ini **otomatis terhubung** (bound) ke spreadsheet Anda — jadi Anda tidak perlu mengisi Spreadsheet ID secara manual.
2. Anda akan melihat file default bernama `Code.gs` berisi kode contoh `function myFunction() {}`. **Hapus semua isi** file tersebut.
3. Buka file `Code.gs` dari paket ZIP yang Anda unduh, **salin seluruh isinya**, lalu **tempel** ke editor `Code.gs` di Apps Script.
4. Klik ikon **disket / Save project** (atau Ctrl+S / Cmd+S).
5. Di panel kiri, klik ikon **+** di sebelah "Files" → pilih **HTML**. Beri nama file: `Index` (huruf besar di awal, tanpa `.html` — Apps Script menambahkannya otomatis).
6. Buka file `index.html` dari paket ZIP, **salin seluruh isinya**, lalu **tempel** ke file `Index.html` yang baru dibuat di Apps Script.
7. Klik **Save project** lagi.

---

## BAGIAN C — MENJALANKAN SETUP AWAL (MEMBUAT SEMUA SHEET & AKUN ADMIN)

1. Di editor Apps Script, pastikan Anda berada di file `Code.gs`.
2. Di bagian atas editor, ada dropdown pemilih fungsi (biasanya bertuliskan `doGet` atau nama fungsi lain). Klik dropdown tersebut dan pilih fungsi **`setupInitialData`**.
3. Klik tombol **Run (▶ Jalankan)** di sebelah dropdown tersebut.
4. **Popup "Authorization required"** akan muncul (ini normal, karena script perlu izin mengakses Spreadsheet Anda):
   - Klik **Review permissions**.
   - Pilih akun Google Anda.
   - Akan muncul peringatan **"Google hasn't verified this app"** — ini wajar karena aplikasi ini milik Anda sendiri, bukan aplikasi pihak ketiga. Klik **Advanced (Lanjutan)** → **Go to [nama project] (unsafe)**.
   - Klik **Allow (Izinkan)**.
5. Tunggu beberapa detik. Jika berhasil, di bagian bawah editor akan muncul log **"Execution completed"**.
6. Kembali ke tab Google Spreadsheet Anda dan **refresh halaman**. Anda akan melihat sheet-sheet baru otomatis dibuat: `SETTINGS`, `USERS`, `CATEGORIES`, `ACTIVITIES`, `PARTICIPANTS`, `ATTENDANCE`, `INFAK`, `SIGNATURES` — lengkap dengan header kolom dan data contoh.
7. **Akun login default** yang otomatis dibuat:
   - Username: `admin`
   - Password: `admin123`
   - **⚠️ WAJIB ganti password ini setelah login pertama kali** (Menu → Profil → Ubah Password).

---

## BAGIAN D — DEPLOY SEBAGAI WEB APP

1. Di editor Apps Script, klik tombol **Deploy** (kanan atas) → **New deployment**.
2. Klik ikon gerigi ⚙️ di sebelah "Select type" → pilih **Web app**.
3. Isi form deployment:
   - **Description**: `Absensi Pengajian v1` (bebas)
   - **Execute as**: **Me (email Anda)**
   - **Who has access**: **Anyone** (agar peserta yang scan QR bisa mengisi tanpa login Google)
4. Klik **Deploy**.
5. Akan muncul popup meminta otorisasi lagi (jika belum) — ikuti langkah yang sama seperti Bagian C poin 4.
6. Setelah berhasil, akan muncul **Web app URL**, formatnya seperti:
   `https://script.google.com/macros/s/AKfycbx.../exec`
7. **Salin URL tersebut** — ini adalah alamat aplikasi Anda yang lengkap (frontend + backend jadi satu).

> Catatan: URL ini otomatis dipakai oleh `index.html` itu sendiri (tidak perlu diedit manual) selama Anda mengakses aplikasi lewat URL `.../exec` ini. Konfigurasi manual (`API_URL_MANUAL` di dalam `index.html`) hanya diperlukan **jika** Anda ingin meng-hosting file `index.html` secara terpisah (misalnya di GitHub Pages/hosting lain) — lihat Bagian G.

---

## BAGIAN E — MEMBUKA & MENGUJI APLIKASI

1. Buka **Web app URL** yang Anda salin tadi di browser (HP atau komputer).
2. Anda akan melihat halaman **Login** dengan sapaan Arab dan desain hijau.
3. Login dengan `admin` / `admin123`.
4. Anda akan masuk ke **Dashboard**. Segera buka **Menu → Profil → Ubah Password**.

---

## BAGIAN F — MEMBUAT KEGIATAN & QR CODE PERTAMA

1. Buka menu **Kegiatan** → tombol **+** di kanan atas.
2. Isi nama kegiatan, kategori, tanggal, jam, dan lokasi → **Simpan**.
3. Anda akan diarahkan ke halaman detail kegiatan yang menampilkan **QR Code unik** dan **link kegiatan unik** (`...exec?activity=ACT-XXXXXXXX`).
4. Gunakan tombol:
   - **Bagikan via WhatsApp** — membuka wa.me dengan pesan siap kirim.
   - **Bagikan via Email** — membuka aplikasi email dengan draft siap kirim.
   - **Unduh QR Code** — menyimpan gambar QR ke perangkat Anda (untuk dicetak/ditempel).

---

## BAGIAN G — (OPSIONAL) HOSTING `index.html` TERPISAH DARI APPS SCRIPT

Jika Anda ingin meng-hosting `index.html` di layanan lain (GitHub Pages, Netlify, dst) alih-alih membukanya lewat URL Apps Script:

1. Buka file `index.html` hasil unduhan (bukan yang di Apps Script).
2. Cari baris berikut di bagian atas file:
   ```js
   const API_URL_MANUAL = "MASUKKAN_URL_WEB_APP_APPS_SCRIPT_DI_SINI";
   ```
3. Ganti teks di dalam tanda kutip dengan **Web app URL** dari Bagian D, contoh:
   ```js
   const API_URL_MANUAL = "https://script.google.com/macros/s/AKfycbx.../exec";
   ```
4. Upload file `index.html` yang sudah diedit ke hosting pilihan Anda.
5. QR Code kegiatan tetap akan mengarah ke URL Apps Script (`.../exec?activity=...`) — itu tetap berfungsi karena Apps Script juga bisa menyajikan halaman. Jika Anda ingin QR mengarah ke hosting terpisah Anda, sesuaikan pola URL pada fungsi `apiCreateActivity_` di `Code.gs` (variabel `webAppUrl`).

---

## BAGIAN H — MEMBUAT PENGGUNA OPERATOR TAMBAHAN

1. Login sebagai Administrator.
2. Buka **Menu → Pengguna** → tombol **+**.
3. Isi nama, username, password, dan pilih role **Operator** (bisa kelola kegiatan/absensi tapi tidak bisa hapus pengguna/kategori).
4. Simpan.

---

## RINGKASAN ARSITEKTUR

```
 SMARTPHONE / TABLET / LAPTOP
           │  (buka index.html via Web App URL, atau scan QR)
           ▼
 GOOGLE APPS SCRIPT (Code.gs)
   - Autentikasi & Role (Administrator / Operator / Peserta)
   - Validasi data (server-side, tidak percaya input frontend)
   - LockService (mencegah data tertimpa saat banyak orang absen bersamaan)
   - Endpoint: login, getSettings, CRUD kategori/kegiatan/peserta,
     submitAttendance, saveInfak, getReports, dll.
           │
           ▼
 GOOGLE SPREADSHEET (Database Utama / Source of Truth)
   SETTINGS · USERS · CATEGORIES · ACTIVITIES · PARTICIPANTS
   ATTENDANCE · INFAK · SIGNATURES
```

**Penting:** `localStorage` di browser HANYA dipakai untuk menyimpan token
sesi login. Seluruh data absensi, peserta, kegiatan, dan infak SELALU
tersimpan di Google Spreadsheet — bukan di perangkat pengguna.
