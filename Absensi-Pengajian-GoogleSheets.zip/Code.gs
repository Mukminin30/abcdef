/**
 * ============================================================================
 *  APLIKASI DAFTAR HADIR / ABSENSI PENGAJIAN
 *  BACKEND: Google Apps Script  |  DATABASE: Google Spreadsheet
 * ============================================================================
 *  File ini adalah SATU-SATUNYA backend aplikasi. Semua data disimpan di
 *  Google Spreadsheet (bukan di localStorage/IndexedDB browser).
 *
 *  CARA PAKAI SINGKAT (lihat SETUP_GUIDE.md untuk panduan lengkap bergambar):
 *   1. Buat Google Spreadsheet baru.
 *   2. Buka menu Extensions > Apps Script.
 *   3. Hapus isi default, tempel seluruh isi file ini ke Code.gs.
 *   4. Buat file HTML baru bernama "Index", tempel isi index.html ke sana.
 *   5. Jalankan fungsi setupInitialData() sekali (lihat panduan).
 *   6. Deploy > New deployment > Web app > Execute as: Me, Access: Anyone.
 *   7. Salin URL Web App. Selesai — index.html otomatis memakai URL itu.
 * ============================================================================
 */

// ============================================================================
// BAGIAN 1: KONFIGURASI
// ============================================================================

// Jika script TIDAK terikat langsung ke Spreadsheet (standalone project),
// isi SPREADSHEET_ID di bawah ini dengan ID spreadsheet Anda.
// Jika Code.gs dibuat dari dalam Spreadsheet (Extensions > Apps Script),
// baris ini boleh dibiarkan kosong karena getActiveSpreadsheet() akan dipakai.
const SPREADSHEET_ID = ''; // contoh: '1AbCJj9......xyz'

// Nama-nama sheet (tabel) yang digunakan sebagai database.
const SHEETS = {
  SETTINGS: 'SETTINGS',
  USERS: 'USERS',
  CATEGORIES: 'CATEGORIES',
  ACTIVITIES: 'ACTIVITIES',
  PARTICIPANTS: 'PARTICIPANTS',
  ATTENDANCE: 'ATTENDANCE',
  INFAK: 'INFAK',
  SIGNATURES: 'SIGNATURES'
};

// Definisi kolom (header) setiap sheet — WAJIB SESUAI dengan spesifikasi.
const HEADERS = {
  SETTINGS: ['ID', 'KEY', 'VALUE', 'DESCRIPTION', 'UPDATED_AT'],
  USERS: ['ID', 'USERNAME', 'PASSWORD_HASH', 'SALT', 'NAMA', 'ROLE', 'EMAIL', 'NO_HP', 'STATUS', 'CREATED_AT', 'UPDATED_AT'],
  CATEGORIES: ['ID', 'NAMA_KATEGORI', 'ICON', 'URUTAN', 'STATUS', 'CREATED_AT', 'UPDATED_AT'],
  ACTIVITIES: ['ID_KEGIATAN', 'ID_KATEGORI', 'NAMA_KEGIATAN', 'DESKRIPSI', 'TANGGAL', 'JAM_MULAI', 'JAM_SELESAI', 'LOKASI', 'QR_TOKEN', 'QR_URL', 'STATUS', 'CREATED_BY', 'CREATED_AT', 'UPDATED_AT'],
  PARTICIPANTS: ['ID_PESERTA', 'NAMA', 'JENIS_KELAMIN', 'STATUS', 'DAPUKAN', 'NO_HP', 'EMAIL', 'CREATED_AT', 'UPDATED_AT'],
  ATTENDANCE: ['ID_ABSENSI', 'ID_KEGIATAN', 'ID_PESERTA', 'NO', 'NAMA', 'JENIS_KELAMIN', 'STATUS', 'DAPUKAN', 'WAKTU_DATANG', 'ZONA_WAKTU', 'KEHADIRAN', 'KETERANGAN', 'METODE_INPUT', 'QR_TOKEN', 'SIGNATURE', 'SIGNATURE_TIMESTAMP', 'CREATED_AT', 'UPDATED_AT'],
  INFAK: ['ID_INFAK', 'ID_KEGIATAN', 'ID_PESERTA', 'NAMA', 'NOMINAL', 'KETERANGAN', 'WAKTU', 'METODE', 'CREATED_AT'],
  SIGNATURES: ['ID_SIGNATURE', 'ID_KEGIATAN', 'ID_ABSENSI', 'ID_PESERTA', 'TYPE', 'NAMA_PENANDATANGAN', 'DAPUKAN_PENANDATANGAN', 'SIGNATURE_DATA', 'CREATED_AT']
};

const DEFAULT_TIMEZONE = 'Asia/Jakarta'; // WIB. Ganti sesuai lokasi masjid jika perlu.
const TOKEN_LIFETIME_MS = 8 * 60 * 60 * 1000; // 8 jam

// ============================================================================
// BAGIAN 2: ENTRY POINT (doGet / doPost)
// ============================================================================

function doGet(e) {
  e = e || { parameter: {} };
  // Jika ada parameter "action", perlakukan sebagai panggilan API (GET API).
  if (e.parameter && e.parameter.action) {
    return handleApiRequest(e.parameter.action, safeParseJson_(e.parameter.payload) || {}, e.parameter.token || '');
  }
  // Jika tidak ada action, sajikan halaman index.html (frontend).
  var tmpl = HtmlService.createTemplateFromFile('Index');
  tmpl.activityId = e.parameter.activity || '';
  return tmpl.evaluate()
    .setTitle('Daftar Hadir Pengajian')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  try {
    var body = {};
    if (e.postData && e.postData.contents) {
      body = JSON.parse(e.postData.contents);
    }
    return handleApiRequest(body.action, body.payload || {}, body.token || '');
  } catch (err) {
    return jsonOut_({ success: false, message: 'Gagal memproses request: ' + err.message });
  }
}

// Dipanggil dari index.html jika di-host via Apps Script (menghindari CORS sama sekali).
function apiCall(action, payload, token) {
  var result = routeAction_(action, payload || {}, token || '');
  return result;
}

function handleApiRequest(action, payload, token) {
  var result = routeAction_(action, payload, token);
  return jsonOut_(result);
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function safeParseJson_(str) {
  try { return JSON.parse(str); } catch (e) { return null; }
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ============================================================================
// BAGIAN 3: ROUTER AKSI — SEMUA ENDPOINT API ADA DI SINI
// ============================================================================

function routeAction_(action, payload, token) {
  try {
    switch (action) {
      // ---- PUBLIK (tidak perlu login) ----
      case 'ping': return { success: true, message: 'pong', time: new Date().toISOString() };
      case 'login': return apiLogin_(payload);
      case 'getSettings': return apiGetSettings_();
      case 'getActivityByToken': return apiGetActivityByToken_(payload);
      case 'checkAttendance': return apiCheckAttendance_(payload);
      case 'submitAttendance': return apiSubmitAttendance_(payload, token);
      case 'saveInfak': return apiSaveInfak_(payload, token);
      case 'getCategories': return apiGetCategories_(false);

      // ---- BUTUH LOGIN (Operator / Administrator) ----
      case 'saveSettings': requireRole_(token, ['ADMINISTRATOR']); return apiSaveSettings_(payload);
      case 'createCategory': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiCreateCategory_(payload);
      case 'updateCategory': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiUpdateCategory_(payload);
      case 'deleteCategory': requireRole_(token, ['ADMINISTRATOR']); return apiDeleteCategory_(payload);

      case 'getActivities': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetActivities_(payload);
      case 'createActivity': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiCreateActivity_(payload, token);
      case 'updateActivity': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiUpdateActivity_(payload);
      case 'deleteActivity': requireRole_(token, ['ADMINISTRATOR']); return apiDeleteActivity_(payload);

      case 'getParticipants': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetParticipants_(payload);
      case 'createParticipant': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiCreateParticipant_(payload);
      case 'updateParticipant': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiUpdateParticipant_(payload);
      case 'deleteParticipant': requireRole_(token, ['ADMINISTRATOR']); return apiDeleteParticipant_(payload);

      case 'getAttendance': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetAttendance_(payload);
      case 'updateAttendance': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiUpdateAttendance_(payload);
      case 'deleteAttendance': requireRole_(token, ['ADMINISTRATOR']); return apiDeleteAttendance_(payload);

      case 'getInfak': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetInfak_(payload);

      case 'getDashboard': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetDashboard_();
      case 'getReports': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetReports_(payload);

      case 'savePJSignature': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiSavePJSignature_(payload);
      case 'getPJSignature': requireRole_(token, ['ADMINISTRATOR', 'OPERATOR']); return apiGetPJSignature_(payload);

      // ---- KHUSUS ADMINISTRATOR ----
      case 'getUsers': requireRole_(token, ['ADMINISTRATOR']); return apiGetUsers_();
      case 'createUser': requireRole_(token, ['ADMINISTRATOR']); return apiCreateUser_(payload);
      case 'updateUser': requireRole_(token, ['ADMINISTRATOR']); return apiUpdateUser_(payload);
      case 'deleteUser': requireRole_(token, ['ADMINISTRATOR']); return apiDeleteUser_(payload);
      case 'changePassword': return apiChangePassword_(payload, token);

      case 'migrateLocalData': requireRole_(token, ['ADMINISTRATOR']); return apiMigrateLocalData_(payload);

      default:
        return { success: false, message: 'Aksi tidak dikenali: ' + action };
    }
  } catch (err) {
    return { success: false, message: err.message };
  }
}

// ============================================================================
// BAGIAN 4: HELPER SPREADSHEET
// ============================================================================

function getSS_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss) return ss;
  if (!SPREADSHEET_ID) throw new Error('SPREADSHEET_ID belum diisi di Code.gs');
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function getSheet_(name) {
  var ss = getSS_();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, HEADERS[name].length).setValues([HEADERS[name]]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function sheetToObjects_(name) {
  var sheet = getSheet_(name);
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0];
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var obj = {};
    for (var j = 0; j < headers.length; j++) obj[headers[j]] = values[i][j];
    obj._row = i + 1; // nomor baris asli di sheet (untuk update/hapus)
    rows.push(obj);
  }
  return rows;
}

function appendRow_(name, obj) {
  var sheet = getSheet_(name);
  var headers = HEADERS[name];
  var row = headers.map(function (h) { return (obj[h] === undefined || obj[h] === null) ? '' : obj[h]; });
  sheet.appendRow(row);
  return sheet.getLastRow();
}

function updateRowById_(name, idField, idValue, updates) {
  var sheet = getSheet_(name);
  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var idCol = headers.indexOf(idField);
  if (idCol === -1) throw new Error('Kolom ID tidak ditemukan: ' + idField);
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][idCol]) === String(idValue)) {
      headers.forEach(function (h, colIdx) {
        if (updates.hasOwnProperty(h)) {
          sheet.getRange(i + 1, colIdx + 1).setValue(updates[h]);
        }
      });
      return true;
    }
  }
  return false;
}

function deleteRowById_(name, idField, idValue) {
  var sheet = getSheet_(name);
  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var idCol = headers.indexOf(idField);
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][idCol]) === String(idValue)) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

function findRowById_(name, idField, idValue) {
  var rows = sheetToObjects_(name);
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][idField]) === String(idValue)) return rows[i];
  }
  return null;
}

function nowIso_() {
  return new Date().toISOString();
}

function genId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), DEFAULT_TIMEZONE, 'yyyyMMdd') + '-' + Utilities.getUuid().slice(0, 6).toUpperCase();
}

// ============================================================================
// BAGIAN 5: SETUP AWAL — JALANKAN SEKALI SAJA DARI EDITOR APPS SCRIPT
// ============================================================================

/**
 * JALANKAN FUNGSI INI SATU KALI (klik dropdown fungsi di toolbar Apps Script,
 * pilih "setupInitialData", lalu klik Run) untuk membuat seluruh sheet,
 * header kolom, akun admin default, dan pengaturan default.
 */
function setupInitialData() {
  // Buat semua sheet + header
  Object.keys(SHEETS).forEach(function (key) { getSheet_(SHEETS[key]); });

  // Hapus sheet default "Sheet1" jika masih kosong dan tidak dipakai
  var ss = getSS_();
  var defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && ss.getSheets().length > 1) {
    var lastRow = defaultSheet.getLastRow();
    if (lastRow === 0) ss.deleteSheet(defaultSheet);
  }

  // Buat akun Administrator default jika USERS masih kosong
  var users = sheetToObjects_(SHEETS.USERS);
  if (users.length === 0) {
    var salt = Utilities.getUuid();
    appendRow_(SHEETS.USERS, {
      ID: genId_('USR'),
      USERNAME: 'admin',
      PASSWORD_HASH: hashPassword_('admin123', salt),
      SALT: salt,
      NAMA: 'Administrator',
      ROLE: 'ADMINISTRATOR',
      EMAIL: '',
      NO_HP: '',
      STATUS: 'AKTIF',
      CREATED_AT: nowIso_(),
      UPDATED_AT: nowIso_()
    });
  }

  // Isi pengaturan default jika SETTINGS masih kosong
  var settings = sheetToObjects_(SHEETS.SETTINGS);
  if (settings.length === 0) {
    var defaults = {
      APP_TITLE: 'Daftar Hadir Pengajian',
      ORG_NAME: 'Nama Organisasi',
      MOSQUE_NAME: 'Masjid Al-Ikhlas',
      MAJELIS_NAME: 'Pengajian Rutin',
      ADDRESS: 'Alamat masjid/majelis Anda',
      PHONE: '',
      LOGO_URL: '',
      THEME_COLOR: '#16a34a',
      BANNER_URL: '',
      FOOTER_TEXT: 'Aplikasi Daftar Hadir Pengajian',
      INFO_TEXT: 'Silakan isi daftar hadir dengan data yang benar.',
      TIMEZONE_DEFAULT: 'WIB'
    };
    Object.keys(defaults).forEach(function (key) {
      appendRow_(SHEETS.SETTINGS, {
        ID: genId_('SET'),
        KEY: key,
        VALUE: defaults[key],
        DESCRIPTION: '',
        UPDATED_AT: nowIso_()
      });
    });
  }

  // Isi contoh kategori default jika CATEGORIES masih kosong
  var cats = sheetToObjects_(SHEETS.CATEGORIES);
  if (cats.length === 0) {
    var defaultCats = [
      ['Pengajian Umum', 'users'],
      ['Pengajian Bapak-Bapak', 'user'],
      ['Pengajian Ibu-Ibu', 'user-round'],
      ['Pengajian Muda-Mudi', 'sparkles'],
      ['Pengajian Remaja', 'book-open'],
      ['Pengajian Pra Remaja', 'smile'],
      ['Pengajian Caberawit', 'baby']
    ];
    defaultCats.forEach(function (c, idx) {
      appendRow_(SHEETS.CATEGORIES, {
        ID: genId_('CAT'),
        NAMA_KATEGORI: c[0],
        ICON: c[1],
        URUTAN: idx + 1,
        STATUS: 'AKTIF',
        CREATED_AT: nowIso_(),
        UPDATED_AT: nowIso_()
      });
    });
  }

  // Buat secret untuk penandatanganan token jika belum ada
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('AUTH_SECRET')) {
    props.setProperty('AUTH_SECRET', Utilities.getUuid() + Utilities.getUuid());
  }

  Logger.log('Setup selesai. Login default -> username: admin | password: admin123');
  Logger.log('SEGERA GANTI PASSWORD ADMIN setelah login pertama kali!');
}

// ============================================================================
// BAGIAN 6: AUTENTIKASI & KEAMANAN
// ============================================================================

function hashPassword_(password, salt) {
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + '::' + password);
  return digest.map(function (b) { return ('0' + (b & 0xFF).toString(16)).slice(-2); }).join('');
}

function getAuthSecret_() {
  var props = PropertiesService.getScriptProperties();
  var secret = props.getProperty('AUTH_SECRET');
  if (!secret) {
    secret = Utilities.getUuid() + Utilities.getUuid();
    props.setProperty('AUTH_SECRET', secret);
  }
  return secret;
}

function createToken_(user) {
  var payload = {
    id: user.ID,
    u: user.USERNAME,
    n: user.NAMA,
    r: user.ROLE,
    exp: Date.now() + TOKEN_LIFETIME_MS
  };
  var payloadStr = Utilities.base64EncodeWebSafe(JSON.stringify(payload));
  var sig = Utilities.base64EncodeWebSafe(
    Utilities.computeHmacSha256Signature(payloadStr, getAuthSecret_())
  );
  return payloadStr + '.' + sig;
}

function verifyToken_(token) {
  if (!token || token.indexOf('.') === -1) throw new Error('Sesi tidak valid. Silakan login kembali.');
  var parts = token.split('.');
  var payloadStr = parts[0], sig = parts[1];
  var expectedSig = Utilities.base64EncodeWebSafe(
    Utilities.computeHmacSha256Signature(payloadStr, getAuthSecret_())
  );
  if (sig !== expectedSig) throw new Error('Sesi tidak valid (signature).');
  var payload = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(payloadStr)).getDataAsString());
  if (Date.now() > payload.exp) throw new Error('Sesi telah kedaluwarsa. Silakan login kembali.');
  return payload;
}

function requireRole_(token, allowedRoles) {
  var payload = verifyToken_(token);
  if (allowedRoles.indexOf(payload.r) === -1) {
    throw new Error('Anda tidak memiliki akses untuk aksi ini.');
  }
  return payload;
}

// ============================================================================
// BAGIAN 7: AUTH & USERS
// ============================================================================

function apiLogin_(payload) {
  var username = (payload.username || '').trim();
  var password = payload.password || '';
  if (!username || !password) return { success: false, message: 'Username dan password wajib diisi.' };

  var users = sheetToObjects_(SHEETS.USERS);
  var user = users.find(function (u) { return String(u.USERNAME).toLowerCase() === username.toLowerCase(); });
  if (!user) return { success: false, message: 'Username tidak ditemukan.' };
  if (String(user.STATUS).toUpperCase() === 'NONAKTIF') return { success: false, message: 'Akun Anda dinonaktifkan. Hubungi Administrator.' };

  var hash = hashPassword_(password, user.SALT);
  if (hash !== user.PASSWORD_HASH) return { success: false, message: 'Password salah.' };

  var token = createToken_(user);
  return {
    success: true,
    message: 'Login berhasil',
    data: {
      token: token,
      user: { id: user.ID, username: user.USERNAME, nama: user.NAMA, role: user.ROLE, email: user.EMAIL }
    }
  };
}

function apiChangePassword_(payload, token) {
  var session = verifyToken_(token);
  var users = sheetToObjects_(SHEETS.USERS);
  var user = users.find(function (u) { return u.ID === session.id; });
  if (!user) return { success: false, message: 'Pengguna tidak ditemukan.' };
  var oldHash = hashPassword_(payload.oldPassword || '', user.SALT);
  if (oldHash !== user.PASSWORD_HASH) return { success: false, message: 'Password lama salah.' };
  var newSalt = Utilities.getUuid();
  var newHash = hashPassword_(payload.newPassword || '', newSalt);
  updateRowById_(SHEETS.USERS, 'ID', user.ID, { PASSWORD_HASH: newHash, SALT: newSalt, UPDATED_AT: nowIso_() });
  return { success: true, message: 'Password berhasil diubah.' };
}

function apiGetUsers_() {
  var users = sheetToObjects_(SHEETS.USERS).map(function (u) {
    return { ID: u.ID, USERNAME: u.USERNAME, NAMA: u.NAMA, ROLE: u.ROLE, EMAIL: u.EMAIL, NO_HP: u.NO_HP, STATUS: u.STATUS };
  });
  return { success: true, data: users };
}

function apiCreateUser_(payload) {
  if (!payload.username || !payload.password || !payload.nama || !payload.role) {
    return { success: false, message: 'Data pengguna belum lengkap.' };
  }
  var users = sheetToObjects_(SHEETS.USERS);
  var exists = users.some(function (u) { return String(u.USERNAME).toLowerCase() === payload.username.toLowerCase(); });
  if (exists) return { success: false, message: 'Username sudah digunakan.' };

  var salt = Utilities.getUuid();
  appendRow_(SHEETS.USERS, {
    ID: genId_('USR'),
    USERNAME: payload.username.trim(),
    PASSWORD_HASH: hashPassword_(payload.password, salt),
    SALT: salt,
    NAMA: payload.nama,
    ROLE: payload.role,
    EMAIL: payload.email || '',
    NO_HP: payload.noHp || '',
    STATUS: 'AKTIF',
    CREATED_AT: nowIso_(),
    UPDATED_AT: nowIso_()
  });
  return { success: true, message: 'Pengguna berhasil ditambahkan.' };
}

function apiUpdateUser_(payload) {
  if (!payload.id) return { success: false, message: 'ID pengguna wajib diisi.' };
  var updates = { UPDATED_AT: nowIso_() };
  if (payload.nama) updates.NAMA = payload.nama;
  if (payload.role) updates.ROLE = payload.role;
  if (payload.email !== undefined) updates.EMAIL = payload.email;
  if (payload.noHp !== undefined) updates.NO_HP = payload.noHp;
  if (payload.status) updates.STATUS = payload.status;
  if (payload.password) {
    var salt = Utilities.getUuid();
    updates.PASSWORD_HASH = hashPassword_(payload.password, salt);
    updates.SALT = salt;
  }
  var ok = updateRowById_(SHEETS.USERS, 'ID', payload.id, updates);
  return ok ? { success: true, message: 'Pengguna diperbarui.' } : { success: false, message: 'Pengguna tidak ditemukan.' };
}

function apiDeleteUser_(payload) {
  var ok = deleteRowById_(SHEETS.USERS, 'ID', payload.id);
  return ok ? { success: true, message: 'Pengguna dihapus.' } : { success: false, message: 'Pengguna tidak ditemukan.' };
}

// ============================================================================
// BAGIAN 8: SETTINGS (IDENTITAS APLIKASI)
// ============================================================================

function apiGetSettings_() {
  var rows = sheetToObjects_(SHEETS.SETTINGS);
  var settings = {};
  rows.forEach(function (r) { settings[r.KEY] = r.VALUE; });
  return { success: true, data: settings };
}

function apiSaveSettings_(payload) {
  var updates = payload.settings || {};
  var rows = sheetToObjects_(SHEETS.SETTINGS);
  var existingKeys = {};
  rows.forEach(function (r) { existingKeys[r.KEY] = r; });

  Object.keys(updates).forEach(function (key) {
    if (existingKeys[key]) {
      updateRowById_(SHEETS.SETTINGS, 'ID', existingKeys[key].ID, { VALUE: updates[key], UPDATED_AT: nowIso_() });
    } else {
      appendRow_(SHEETS.SETTINGS, { ID: genId_('SET'), KEY: key, VALUE: updates[key], DESCRIPTION: '', UPDATED_AT: nowIso_() });
    }
  });
  return { success: true, message: 'Pengaturan berhasil disimpan.' };
}

// ============================================================================
// BAGIAN 9: KATEGORI PENGAJIAN
// ============================================================================

function apiGetCategories_(includeInactive) {
  var rows = sheetToObjects_(SHEETS.CATEGORIES);
  if (!includeInactive) rows = rows.filter(function (r) { return String(r.STATUS).toUpperCase() !== 'NONAKTIF'; });
  rows.sort(function (a, b) { return (Number(a.URUTAN) || 0) - (Number(b.URUTAN) || 0); });
  return { success: true, data: rows };
}

function apiCreateCategory_(payload) {
  if (!payload.nama) return { success: false, message: 'Nama kategori wajib diisi.' };
  var rows = sheetToObjects_(SHEETS.CATEGORIES);
  appendRow_(SHEETS.CATEGORIES, {
    ID: genId_('CAT'),
    NAMA_KATEGORI: payload.nama,
    ICON: payload.icon || 'book-open',
    URUTAN: payload.urutan || (rows.length + 1),
    STATUS: 'AKTIF',
    CREATED_AT: nowIso_(),
    UPDATED_AT: nowIso_()
  });
  return { success: true, message: 'Kategori ditambahkan.' };
}

function apiUpdateCategory_(payload) {
  var updates = { UPDATED_AT: nowIso_() };
  if (payload.nama) updates.NAMA_KATEGORI = payload.nama;
  if (payload.icon) updates.ICON = payload.icon;
  if (payload.urutan !== undefined) updates.URUTAN = payload.urutan;
  if (payload.status) updates.STATUS = payload.status;
  var ok = updateRowById_(SHEETS.CATEGORIES, 'ID', payload.id, updates);
  return ok ? { success: true, message: 'Kategori diperbarui.' } : { success: false, message: 'Kategori tidak ditemukan.' };
}

function apiDeleteCategory_(payload) {
  var ok = deleteRowById_(SHEETS.CATEGORIES, 'ID', payload.id);
  return ok ? { success: true, message: 'Kategori dihapus.' } : { success: false, message: 'Kategori tidak ditemukan.' };
}

// ============================================================================
// BAGIAN 10: KEGIATAN + QR CODE (1 KEGIATAN = 1 QR = 1 LINK)
// ============================================================================

function apiGetActivities_(payload) {
  var rows = sheetToObjects_(SHEETS.ACTIVITIES);
  if (payload && payload.status && payload.status !== 'SEMUA') {
    rows = rows.filter(function (r) { return r.STATUS === payload.status; });
  }
  rows.sort(function (a, b) { return new Date(b.TANGGAL) - new Date(a.TANGGAL); });
  // Sertakan ringkasan hadir & infak per kegiatan
  var attendance = sheetToObjects_(SHEETS.ATTENDANCE);
  var infak = sheetToObjects_(SHEETS.INFAK);
  rows.forEach(function (act) {
    var actAtt = attendance.filter(function (a) { return a.ID_KEGIATAN === act.ID_KEGIATAN; });
    act.TOTAL_HADIR = actAtt.filter(function (a) { return a.KEHADIRAN === 'Hadir'; }).length;
    act.TOTAL_ABSENSI = actAtt.length;
    act.TOTAL_INFAK = infak.filter(function (i) { return i.ID_KEGIATAN === act.ID_KEGIATAN; })
      .reduce(function (sum, i) { return sum + (Number(i.NOMINAL) || 0); }, 0);
  });
  return { success: true, data: rows };
}

function apiCreateActivity_(payload, token) {
  if (!payload.namaKegiatan || !payload.tanggal) return { success: false, message: 'Nama kegiatan dan tanggal wajib diisi.' };
  var session = null;
  try { session = verifyToken_(token); } catch (e) {}

  var id = genId_('ACT');
  var qrToken = Utilities.getUuid();
  var webAppUrl = ScriptApp.getService().getUrl();
  var qrUrl = webAppUrl + '?activity=' + id;

  appendRow_(SHEETS.ACTIVITIES, {
    ID_KEGIATAN: id,
    ID_KATEGORI: payload.idKategori || '',
    NAMA_KEGIATAN: payload.namaKegiatan,
    DESKRIPSI: payload.deskripsi || '',
    TANGGAL: payload.tanggal,
    JAM_MULAI: payload.jamMulai || '',
    JAM_SELESAI: payload.jamSelesai || '',
    LOKASI: payload.lokasi || '',
    QR_TOKEN: qrToken,
    QR_URL: qrUrl,
    STATUS: 'AKTIF',
    CREATED_BY: session ? session.u : 'system',
    CREATED_AT: nowIso_(),
    UPDATED_AT: nowIso_()
  });
  return { success: true, message: 'Kegiatan berhasil dibuat.', data: { id: id, qrUrl: qrUrl, qrToken: qrToken } };
}

function apiUpdateActivity_(payload) {
  var updates = { UPDATED_AT: nowIso_() };
  var map = { namaKegiatan: 'NAMA_KEGIATAN', deskripsi: 'DESKRIPSI', tanggal: 'TANGGAL', jamMulai: 'JAM_MULAI', jamSelesai: 'JAM_SELESAI', lokasi: 'LOKASI', idKategori: 'ID_KATEGORI', status: 'STATUS' };
  Object.keys(map).forEach(function (k) { if (payload[k] !== undefined) updates[map[k]] = payload[k]; });
  var ok = updateRowById_(SHEETS.ACTIVITIES, 'ID_KEGIATAN', payload.id, updates);
  return ok ? { success: true, message: 'Kegiatan diperbarui.' } : { success: false, message: 'Kegiatan tidak ditemukan.' };
}

function apiDeleteActivity_(payload) {
  var ok = deleteRowById_(SHEETS.ACTIVITIES, 'ID_KEGIATAN', payload.id);
  return ok ? { success: true, message: 'Kegiatan dihapus.' } : { success: false, message: 'Kegiatan tidak ditemukan.' };
}

// Dipanggil publik saat QR di-scan / link dibuka, untuk mengambil detail kegiatan.
function apiGetActivityByToken_(payload) {
  var id = payload.id;
  var rows = sheetToObjects_(SHEETS.ACTIVITIES);
  var act = rows.find(function (a) { return a.ID_KEGIATAN === id; });
  if (!act) return { success: false, message: 'Kegiatan tidak ditemukan atau link tidak valid.' };
  if (String(act.STATUS).toUpperCase() !== 'AKTIF') return { success: false, message: 'Kegiatan ini sudah tidak aktif / selesai.' };
  return {
    success: true,
    data: {
      id: act.ID_KEGIATAN, nama: act.NAMA_KEGIATAN, deskripsi: act.DESKRIPSI, tanggal: act.TANGGAL,
      jamMulai: act.JAM_MULAI, jamSelesai: act.JAM_SELESAI, lokasi: act.LOKASI, qrToken: act.QR_TOKEN
    }
  };
}

// ============================================================================
// BAGIAN 11: PESERTA (MASTER DATA)
// ============================================================================

function apiGetParticipants_(payload) {
  var rows = sheetToObjects_(SHEETS.PARTICIPANTS);
  if (payload && payload.search) {
    var q = payload.search.toLowerCase();
    rows = rows.filter(function (r) { return String(r.NAMA).toLowerCase().indexOf(q) !== -1; });
  }
  return { success: true, data: rows };
}

function apiCreateParticipant_(payload) {
  if (!payload.nama) return { success: false, message: 'Nama peserta wajib diisi.' };
  var id = genId_('PST');
  appendRow_(SHEETS.PARTICIPANTS, {
    ID_PESERTA: id, NAMA: payload.nama, JENIS_KELAMIN: payload.jenisKelamin || '',
    STATUS: payload.status || '', DAPUKAN: payload.dapukan || '', NO_HP: payload.noHp || '',
    EMAIL: payload.email || '', CREATED_AT: nowIso_(), UPDATED_AT: nowIso_()
  });
  return { success: true, message: 'Peserta ditambahkan.', data: { id: id } };
}

function apiUpdateParticipant_(payload) {
  var updates = { UPDATED_AT: nowIso_() };
  var map = { nama: 'NAMA', jenisKelamin: 'JENIS_KELAMIN', status: 'STATUS', dapukan: 'DAPUKAN', noHp: 'NO_HP', email: 'EMAIL' };
  Object.keys(map).forEach(function (k) { if (payload[k] !== undefined) updates[map[k]] = payload[k]; });
  var ok = updateRowById_(SHEETS.PARTICIPANTS, 'ID_PESERTA', payload.id, updates);
  return ok ? { success: true, message: 'Peserta diperbarui.' } : { success: false, message: 'Peserta tidak ditemukan.' };
}

function apiDeleteParticipant_(payload) {
  var ok = deleteRowById_(SHEETS.PARTICIPANTS, 'ID_PESERTA', payload.id);
  return ok ? { success: true, message: 'Peserta dihapus.' } : { success: false, message: 'Peserta tidak ditemukan.' };
}

// ============================================================================
// BAGIAN 12: ABSENSI (QR + MANUAL) — DENGAN LOCK & ANTI DUPLIKAT
// ============================================================================

function apiCheckAttendance_(payload) {
  var idKegiatan = payload.idKegiatan;
  var nama = (payload.nama || '').trim().toLowerCase();
  var noHp = (payload.noHp || '').trim();
  var rows = sheetToObjects_(SHEETS.ATTENDANCE);
  var found = rows.find(function (r) {
    if (r.ID_KEGIATAN !== idKegiatan) return false;
    if (payload.idPeserta && r.ID_PESERTA === payload.idPeserta) return true;
    var sameName = String(r.NAMA).trim().toLowerCase() === nama;
    var samePhone = noHp && String(r.NO_HP || '') === noHp;
    return sameName && (noHp ? samePhone : true);
  });
  return { success: true, data: { sudahAbsen: !!found, absensi: found || null } };
}

function apiSubmitAttendance_(payload, token) {
  var lock = LockService.getScriptLock();
  var gotLock = lock.tryLock(25000);
  if (!gotLock) return { success: false, message: 'Sistem sedang sibuk, silakan coba lagi beberapa saat.' };

  try {
    // --- Validasi dasar (backend TIDAK boleh percaya validasi frontend) ---
    if (!payload.idKegiatan) return { success: false, message: 'ID kegiatan wajib diisi.' };
    if (!payload.nama || String(payload.nama).trim().length < 2) return { success: false, message: 'Nama peserta wajib diisi.' };
    if (!payload.kehadiran) return { success: false, message: 'Status kehadiran wajib dipilih.' };

    var activities = sheetToObjects_(SHEETS.ACTIVITIES);
    var activity = activities.find(function (a) { return a.ID_KEGIATAN === payload.idKegiatan; });
    if (!activity) return { success: false, message: 'Kegiatan tidak ditemukan.' };
    if (String(activity.STATUS).toUpperCase() !== 'AKTIF') return { success: false, message: 'Kegiatan ini sudah tidak aktif.' };

    // Jika absensi via QR, token kegiatan wajib cocok (mencegah tebak ID kegiatan)
    if (payload.metodeInput === 'QR') {
      if (!payload.qrToken || payload.qrToken !== activity.QR_TOKEN) {
        return { success: false, message: 'Token QR tidak valid. Silakan scan ulang QR Code.' };
      }
    }

    // --- Cegah absensi ganda (validasi ulang di server, bukan hanya di frontend) ---
    var attendanceRows = sheetToObjects_(SHEETS.ATTENDANCE);
    var namaLower = String(payload.nama).trim().toLowerCase();
    var noHp = String(payload.noHp || '').trim();
    var duplikat = attendanceRows.find(function (r) {
      if (r.ID_KEGIATAN !== payload.idKegiatan) return false;
      if (payload.idPeserta && r.ID_PESERTA === payload.idPeserta) return true;
      var sameName = String(r.NAMA).trim().toLowerCase() === namaLower;
      var samePhone = noHp && String(r.NO_HP || '') === noHp;
      return sameName && (noHp ? samePhone : true);
    });
    if (duplikat) {
      return { success: false, message: 'Anda sudah melakukan absensi pada kegiatan ini.', data: { duplikat: true, absensi: duplikat } };
    }

    // --- Nomor urut dihitung dari data backend, bukan dari array.length frontend ---
    var noUrut = attendanceRows.filter(function (r) { return r.ID_KEGIATAN === payload.idKegiatan; }).length + 1;

    // --- Waktu datang dicatat oleh SERVER (zona waktu tidak bisa dimanipulasi peserta) ---
    var zonaWaktu = payload.zonaWaktu || 'WIB';
    var tzMap = { WIB: 'Asia/Jakarta', WITA: 'Asia/Makassar', WIT: 'Asia/Jayapura' };
    var tz = tzMap[zonaWaktu] || DEFAULT_TIMEZONE;
    var waktuDatang = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd HH:mm:ss');

    var idAbsensi = genId_('ABS');
    appendRow_(SHEETS.ATTENDANCE, {
      ID_ABSENSI: idAbsensi,
      ID_KEGIATAN: payload.idKegiatan,
      ID_PESERTA: payload.idPeserta || '',
      NO: noUrut,
      NAMA: payload.nama,
      JENIS_KELAMIN: payload.jenisKelamin || '',
      STATUS: payload.status || '',
      DAPUKAN: payload.dapukan || '',
      WAKTU_DATANG: waktuDatang,
      ZONA_WAKTU: zonaWaktu,
      KEHADIRAN: payload.kehadiran,
      KETERANGAN: payload.keterangan || '',
      METODE_INPUT: payload.metodeInput || 'MANUAL',
      QR_TOKEN: payload.qrToken || '',
      SIGNATURE: payload.signature || '',
      SIGNATURE_TIMESTAMP: payload.signature ? nowIso_() : '',
      CREATED_AT: nowIso_(),
      UPDATED_AT: nowIso_()
    });

    // Simpan infak jika disertakan dalam form yang sama
    if (payload.infak && Number(payload.infak.nominal) > 0) {
      appendRow_(SHEETS.INFAK, {
        ID_INFAK: genId_('INF'),
        ID_KEGIATAN: payload.idKegiatan,
        ID_PESERTA: payload.idPeserta || '',
        NAMA: payload.nama,
        NOMINAL: Number(payload.infak.nominal),
        KETERANGAN: payload.infak.keterangan || '',
        WAKTU: waktuDatang,
        METODE: payload.infak.metode || 'Tunai',
        CREATED_AT: nowIso_()
      });
    }

    return { success: true, message: 'Absensi berhasil disimpan', data: { idAbsensi: idAbsensi, no: noUrut, waktuDatang: waktuDatang } };
  } finally {
    lock.releaseLock();
  }
}

function apiGetAttendance_(payload) {
  var rows = sheetToObjects_(SHEETS.ATTENDANCE);
  if (payload && payload.idKegiatan) rows = rows.filter(function (r) { return r.ID_KEGIATAN === payload.idKegiatan; });
  rows.sort(function (a, b) { return Number(a.NO) - Number(b.NO); });
  return { success: true, data: rows };
}

function apiUpdateAttendance_(payload) {
  var updates = { UPDATED_AT: nowIso_() };
  var map = { kehadiran: 'KEHADIRAN', keterangan: 'KETERANGAN', dapukan: 'DAPUKAN', status: 'STATUS', jenisKelamin: 'JENIS_KELAMIN' };
  Object.keys(map).forEach(function (k) { if (payload[k] !== undefined) updates[map[k]] = payload[k]; });
  var ok = updateRowById_(SHEETS.ATTENDANCE, 'ID_ABSENSI', payload.id, updates);
  return ok ? { success: true, message: 'Data absensi diperbarui.' } : { success: false, message: 'Data absensi tidak ditemukan.' };
}

function apiDeleteAttendance_(payload) {
  var ok = deleteRowById_(SHEETS.ATTENDANCE, 'ID_ABSENSI', payload.id);
  return ok ? { success: true, message: 'Data absensi dihapus.' } : { success: false, message: 'Data absensi tidak ditemukan.' };
}

// ============================================================================
// BAGIAN 13: INFAK (SHEET TERPISAH DARI ABSENSI)
// ============================================================================

function apiSaveInfak_(payload, token) {
  if (!payload.idKegiatan || !payload.nominal) return { success: false, message: 'Kegiatan dan nominal infak wajib diisi.' };
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var id = genId_('INF');
    appendRow_(SHEETS.INFAK, {
      ID_INFAK: id, ID_KEGIATAN: payload.idKegiatan, ID_PESERTA: payload.idPeserta || '',
      NAMA: payload.nama || 'Hamba Allah', NOMINAL: Number(payload.nominal),
      KETERANGAN: payload.keterangan || '', WAKTU: nowIso_(), METODE: payload.metode || 'Tunai',
      CREATED_AT: nowIso_()
    });
    return { success: true, message: 'Infak berhasil dicatat.', data: { id: id } };
  } finally {
    lock.releaseLock();
  }
}

function apiGetInfak_(payload) {
  var rows = sheetToObjects_(SHEETS.INFAK);
  if (payload && payload.idKegiatan) rows = rows.filter(function (r) { return r.ID_KEGIATAN === payload.idKegiatan; });
  var total = rows.reduce(function (sum, r) { return sum + (Number(r.NOMINAL) || 0); }, 0);
  return { success: true, data: rows, total: total };
}

// ============================================================================
// BAGIAN 14: TANDA TANGAN PENANGGUNG JAWAB
// ============================================================================

function apiSavePJSignature_(payload) {
  var sheet = getSheet_(SHEETS.SIGNATURES);
  var rows = sheetToObjects_(SHEETS.SIGNATURES);
  var existing = rows.find(function (r) { return r.ID_KEGIATAN === payload.idKegiatan && r.TYPE === 'PJ'; });
  if (existing) {
    updateRowById_(SHEETS.SIGNATURES, 'ID_SIGNATURE', existing.ID_SIGNATURE, {
      NAMA_PENANDATANGAN: payload.nama, DAPUKAN_PENANDATANGAN: payload.dapukan, SIGNATURE_DATA: payload.signature
    });
  } else {
    appendRow_(SHEETS.SIGNATURES, {
      ID_SIGNATURE: genId_('SIG'), ID_KEGIATAN: payload.idKegiatan, ID_ABSENSI: '', ID_PESERTA: '',
      TYPE: 'PJ', NAMA_PENANDATANGAN: payload.nama, DAPUKAN_PENANDATANGAN: payload.dapukan,
      SIGNATURE_DATA: payload.signature, CREATED_AT: nowIso_()
    });
  }
  return { success: true, message: 'Tanda tangan penanggung jawab disimpan.' };
}

function apiGetPJSignature_(payload) {
  var rows = sheetToObjects_(SHEETS.SIGNATURES);
  var found = rows.find(function (r) { return r.ID_KEGIATAN === payload.idKegiatan && r.TYPE === 'PJ'; });
  return { success: true, data: found || null };
}

// ============================================================================
// BAGIAN 15: DASHBOARD & LAPORAN
// ============================================================================

function apiGetDashboard_() {
  var activities = sheetToObjects_(SHEETS.ACTIVITIES);
  var attendance = sheetToObjects_(SHEETS.ATTENDANCE);
  var infak = sheetToObjects_(SHEETS.INFAK);
  var participants = sheetToObjects_(SHEETS.PARTICIPANTS);

  var todayStr = Utilities.formatDate(new Date(), DEFAULT_TIMEZONE, 'yyyy-MM-dd');
  var isToday = function (dateVal) {
    var d = (dateVal instanceof Date) ? Utilities.formatDate(dateVal, DEFAULT_TIMEZONE, 'yyyy-MM-dd') : String(dateVal).slice(0, 10);
    return d === todayStr;
  };

  var activitiesToday = activities.filter(function (a) { return isToday(a.TANGGAL); });
  var attendanceToday = attendance.filter(function (a) { return String(a.CREATED_AT).slice(0, 10) === todayStr; });
  var infakToday = infak.filter(function (i) { return String(i.CREATED_AT).slice(0, 10) === todayStr; });

  var countBy = function (arr, val) { return arr.filter(function (a) { return a.KEHADIRAN === val; }).length; };

  var upcoming = activities
    .filter(function (a) { return String(a.STATUS).toUpperCase() === 'AKTIF' && new Date(a.TANGGAL) >= new Date(todayStr); })
    .sort(function (a, b) { return new Date(a.TANGGAL) - new Date(b.TANGGAL); })
    .slice(0, 5);

  var recent = attendance
    .sort(function (a, b) { return new Date(b.CREATED_AT) - new Date(a.CREATED_AT); })
    .slice(0, 10);

  return {
    success: true,
    data: {
      totalKegiatan: activities.length,
      kegiatanHariIni: activitiesToday.length,
      totalPeserta: participants.length,
      hadirHariIni: countBy(attendanceToday, 'Hadir'),
      izinHariIni: countBy(attendanceToday, 'Izin'),
      sakitHariIni: countBy(attendanceToday, 'Sakit'),
      alfaHariIni: countBy(attendanceToday, 'Alfa'),
      infakHariIni: infakToday.reduce(function (s, i) { return s + (Number(i.NOMINAL) || 0); }, 0),
      infakTotal: infak.reduce(function (s, i) { return s + (Number(i.NOMINAL) || 0); }, 0),
      kegiatanMendatang: upcoming,
      aktivitasTerbaru: recent
    }
  };
}

function apiGetReports_(payload) {
  payload = payload || {};
  var attendance = sheetToObjects_(SHEETS.ATTENDANCE);
  var activities = sheetToObjects_(SHEETS.ACTIVITIES);
  var infak = sheetToObjects_(SHEETS.INFAK);
  var actById = {};
  activities.forEach(function (a) { actById[a.ID_KEGIATAN] = a; });

  var rows = attendance.filter(function (r) {
    var act = actById[r.ID_KEGIATAN];
    if (payload.idKegiatan && r.ID_KEGIATAN !== payload.idKegiatan) return false;
    if (payload.idKategori && act && act.ID_KATEGORI !== payload.idKategori) return false;
    if (payload.tanggalMulai && act && new Date(act.TANGGAL) < new Date(payload.tanggalMulai)) return false;
    if (payload.tanggalAkhir && act && new Date(act.TANGGAL) > new Date(payload.tanggalAkhir)) return false;
    if (payload.jenisKelamin && r.JENIS_KELAMIN !== payload.jenisKelamin) return false;
    if (payload.status && r.STATUS !== payload.status) return false;
    if (payload.kehadiran && r.KEHADIRAN !== payload.kehadiran) return false;
    return true;
  }).map(function (r) {
    var act = actById[r.ID_KEGIATAN];
    r.NAMA_KEGIATAN = act ? act.NAMA_KEGIATAN : '';
    r.TANGGAL_KEGIATAN = act ? act.TANGGAL : '';
    return r;
  });

  var summary = {
    hadir: rows.filter(function (r) { return r.KEHADIRAN === 'Hadir'; }).length,
    izin: rows.filter(function (r) { return r.KEHADIRAN === 'Izin'; }).length,
    sakit: rows.filter(function (r) { return r.KEHADIRAN === 'Sakit'; }).length,
    alfa: rows.filter(function (r) { return r.KEHADIRAN === 'Alfa'; }).length,
    total: rows.length,
    totalInfak: infak.filter(function (i) {
      return rows.some(function (r) { return r.ID_KEGIATAN === i.ID_KEGIATAN; });
    }).reduce(function (s, i) { return s + (Number(i.NOMINAL) || 0); }, 0)
  };

  return { success: true, data: rows, summary: summary };
}

// ============================================================================
// BAGIAN 16: MIGRASI DATA LAMA (localStorage/IndexedDB) -> GOOGLE SHEETS
// ============================================================================

/**
 * Menerima payload berisi data lama dari browser (dikirim oleh index.html
 * saat pengguna menekan "Migrasi Data Lama") dan memindahkannya ke Sheets.
 * Format payload yang didukung:
 * { participants: [...], activities: [...], attendance: [...] }
 */
function apiMigrateLocalData_(payload) {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  var countPeserta = 0, countKegiatan = 0, countAbsensi = 0;
  try {
    (payload.participants || []).forEach(function (p) {
      appendRow_(SHEETS.PARTICIPANTS, {
        ID_PESERTA: genId_('PST'), NAMA: p.nama || p.NAMA || '', JENIS_KELAMIN: p.jenisKelamin || p.JENIS_KELAMIN || '',
        STATUS: p.status || p.STATUS || '', DAPUKAN: p.dapukan || p.DAPUKAN || '', NO_HP: p.noHp || p.NO_HP || '',
        EMAIL: p.email || p.EMAIL || '', CREATED_AT: nowIso_(), UPDATED_AT: nowIso_()
      });
      countPeserta++;
    });

    (payload.activities || []).forEach(function (a) {
      var id = genId_('ACT');
      appendRow_(SHEETS.ACTIVITIES, {
        ID_KEGIATAN: id, ID_KATEGORI: '', NAMA_KEGIATAN: a.nama || a.NAMA_KEGIATAN || 'Kegiatan (migrasi)',
        DESKRIPSI: a.deskripsi || '', TANGGAL: a.tanggal || a.TANGGAL || nowIso_().slice(0, 10),
        JAM_MULAI: a.jamMulai || '', JAM_SELESAI: a.jamSelesai || '', LOKASI: a.lokasi || '',
        QR_TOKEN: Utilities.getUuid(), QR_URL: '', STATUS: 'AKTIF', CREATED_BY: 'migrasi',
        CREATED_AT: nowIso_(), UPDATED_AT: nowIso_()
      });
      countKegiatan++;
    });

    (payload.attendance || []).forEach(function (r) {
      appendRow_(SHEETS.ATTENDANCE, {
        ID_ABSENSI: genId_('ABS'), ID_KEGIATAN: r.idKegiatan || r.ID_KEGIATAN || '', ID_PESERTA: '',
        NO: r.no || 0, NAMA: r.nama || r.NAMA || '', JENIS_KELAMIN: r.jenisKelamin || '', STATUS: r.status || '',
        DAPUKAN: r.dapukan || '', WAKTU_DATANG: r.waktuDatang || nowIso_(), ZONA_WAKTU: r.zonaWaktu || 'WIB',
        KEHADIRAN: r.kehadiran || 'Hadir', KETERANGAN: r.keterangan || '', METODE_INPUT: 'MIGRASI',
        QR_TOKEN: '', SIGNATURE: '', SIGNATURE_TIMESTAMP: '', CREATED_AT: nowIso_(), UPDATED_AT: nowIso_()
      });
      countAbsensi++;
    });

    return { success: true, message: 'Migrasi selesai.', data: { peserta: countPeserta, kegiatan: countKegiatan, absensi: countAbsensi } };
  } finally {
    lock.releaseLock();
  }
}
