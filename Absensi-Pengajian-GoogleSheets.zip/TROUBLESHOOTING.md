# TROUBLESHOOTING — Solusi Masalah Umum

## 1. CORS / "Failed to fetch"
**Gejala:** Login atau simpan data gagal, muncul pesan "Server tidak dapat dihubungi".
**Penyebab umum:** `Content-Type` request bukan `text/plain`, atau Web App belum di-deploy dengan akses **Anyone**.
**Solusi:**
- Pastikan di `index.html` fungsi `api()` mengirim header `'Content-Type': 'text/plain;charset=utf-8'` (jangan `application/json` — ini memicu preflight CORS yang tidak didukung Apps Script Web App).
- Buka **Deploy → Manage deployments**, pastikan **Who has access = Anyone**.
- Setiap kali Anda mengubah `Code.gs`, Anda harus membuat **New deployment** baru (bukan hanya Save) agar perubahan berlaku pada URL `.../exec` yang sama. Alternatif: gunakan **Deploy → Manage deployments → Edit (pensil) → Version: New version → Deploy**.

## 2. API Tidak Merespons / Loading Terus
**Solusi:**
- Buka `Code.gs` di Apps Script → menu **Executions** (ikon jam) di kiri untuk melihat log error terakhir.
- Pastikan fungsi `setupInitialData()` sudah pernah dijalankan sekali.
- Coba akses `.../exec?action=ping` langsung di browser — harus mengembalikan JSON `{"success":true,"message":"pong",...}`. Jika tidak, deployment bermasalah.

## 3. Spreadsheet Tidak Menerima Data
**Solusi:**
- Pastikan Apps Script dibuat dari dalam Spreadsheet (Extensions → Apps Script) sehingga `getActiveSpreadsheet()` mengarah ke sheet yang benar.
- Jika Anda memakai project Apps Script standalone (terpisah), isi konstanta `SPREADSHEET_ID` di baris atas `Code.gs` dengan ID spreadsheet (bagian di URL Spreadsheet antara `/d/` dan `/edit`).
- Cek sheet tidak sengaja di-rename manual — nama sheet harus persis: `SETTINGS`, `USERS`, `CATEGORIES`, `ACTIVITIES`, `PARTICIPANTS`, `ATTENDANCE`, `INFAK`, `SIGNATURES`.

## 4. Authorization Error / "This app isn't verified"
Ini **normal** untuk script pribadi. Solusi:
- Klik **Advanced (Lanjutan)** → **Go to [nama project] (unsafe)** → **Allow**.
- Jika muncul lagi setiap deploy baru, itu wajar — Google meminta ulang otorisasi tiap kali cakupan (scope) akses berubah signifikan.

## 5. QR Tidak Membuka Kegiatan / "Kegiatan Tidak Ditemukan"
**Solusi:**
- Pastikan kegiatan berstatus **AKTIF** (kegiatan nonaktif/selesai tidak bisa menerima absensi baru).
- Pastikan link QR memakai domain Web App yang **terbaru** (jika Anda redeploy dan URL berubah, QR lama menjadi tidak valid — generate ulang kegiatan atau update `QR_URL` di sheet `ACTIVITIES`).
- Cek parameter `?activity=` di URL sesuai dengan `ID_KEGIATAN` yang ada di sheet `ACTIVITIES`.

## 6. Data Duplikat (Peserta Absen Dua Kali)
Sistem sudah mencegah ini di backend (`Code.gs` fungsi `apiSubmitAttendance_`), berbasis kombinasi ID kegiatan + nama/No HP. Jika masih terjadi:
- Kemungkinan peserta mengisi nama dengan ejaan berbeda (mis. "Ahmad" vs "Ahmad "). Pertimbangkan menambahkan No. HP sebagai identitas tambahan.
- Untuk kontrol lebih ketat, arahkan peserta memilih namanya dari daftar `PARTICIPANTS` yang sudah ada (`ID_PESERTA`) alih-alih mengetik manual.

## 7. Tanda Tangan Tidak Tersimpan
**Solusi:**
- Sel Google Sheets memiliki batas ± 50.000 karakter. Tanda tangan disimpan sebagai base64 PNG — biasanya cukup kecil (canvas dibuat berukuran sedang), tetapi jika Anda memperbesar ukuran signature pad secara signifikan, data bisa terpotong/gagal simpan.
- **Solusi alternatif untuk resolusi tinggi:** simpan file gambar tanda tangan ke Google Drive via `DriveApp`, lalu simpan hanya URL/file ID-nya ke sheet `SIGNATURES`/`ATTENDANCE` (bukan base64 penuh). Ini memerlukan penambahan kode di `Code.gs` menggunakan `DriveApp.createFile()`.

## 8. PDF Gagal Dibuat / Kosong
**Solusi:**
- Pastikan koneksi internet aktif saat export (library jsPDF dimuat dari CDN).
- Jika jumlah peserta sangat banyak (500+), proses bisa memakan waktu beberapa detik — tunggu hingga selesai, jangan tutup tab.
- Pastikan pop-up/download tidak diblokir browser.

## 9. Timezone Salah (WIB/WITA/WIT tertukar)
**Solusi:**
- Waktu datang dicatat oleh **server** Apps Script berdasarkan zona waktu yang dipilih peserta di form (`zonaWaktu`), dikonversi lewat `Utilities.formatDate` dengan mapping `Asia/Jakarta` (WIB), `Asia/Makassar` (WITA), `Asia/Jayapura` (WIT) — lihat `Code.gs` bagian `apiSubmitAttendance_`.
- Aplikasi mendeteksi zona waktu otomatis dari offset jam perangkat peserta (fungsi `detectTimezoneLabel()` di `index.html`). Jika peserta menggunakan HP dengan zona waktu manual yang salah, hasil deteksi bisa keliru — dapat ditambahkan pilihan manual WIB/WITA/WIT di form jika diperlukan.

## 10. Web App URL Salah / Berubah Setelah Redeploy
**Solusi:**
- Jika Anda memilih **Deploy → Manage deployments → Edit → New version**, URL `.../exec` **tetap sama**.
- Jika Anda membuat **New deployment** dari awal (bukan edit versi), URL **akan berubah**. Update kembali semua QR Code/link yang sudah dibagikan, dan (jika hosting `index.html` terpisah) update `API_URL_MANUAL`.

## 11. Keterbatasan Keamanan Google Apps Script Web App (Penting untuk Diketahui)
Agar jujur dan transparan mengenai batasan platform ini:
- Apps Script Web App tidak memiliki sistem session/cookie server-side bawaan — aplikasi ini menggunakan **token bertanda tangan HMAC** (mirip JWT sederhana) yang disimpan di `localStorage` browser sebagai gantinya.
- Siapa pun yang mengetahui URL Web App dapat memanggil endpoint publik (`login`, `getActivityByToken`, `submitAttendance`) — ini memang disengaja agar peserta bisa mengisi absensi tanpa akun. Endpoint sensitif (CRUD data, laporan, pengguna) tetap memerlukan token valid dengan role yang sesuai.
- Untuk keamanan tingkat produksi/skala besar (mis. organisasi dengan ribuan pengguna), pertimbangkan migrasi ke backend khusus (Cloud Functions + Firestore/PostgreSQL) — namun untuk skala pengajian/masjid, arsitektur Apps Script + Spreadsheet ini sudah umum dipakai dan cukup andal.
