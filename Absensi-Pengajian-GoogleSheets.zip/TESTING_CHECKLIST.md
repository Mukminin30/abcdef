# CHECKLIST TESTING

Centang satu per satu setelah deployment selesai (lihat SETUP_GUIDE.md).

## Setup & Login
- [ ] `setupInitialData()` dijalankan tanpa error, sheet-sheet baru muncul di Spreadsheet
- [ ] Web App berhasil di-deploy dan URL `.../exec` bisa dibuka di browser
- [ ] Halaman login tampil dengan benar (logo, sapaan Arab, tema hijau)
- [ ] Login dengan `admin` / `admin123` berhasil masuk ke Dashboard
- [ ] Ubah password admin berhasil (Menu → Profil)
- [ ] Login ulang dengan password baru berhasil

## Kategori
- [ ] Tambah kategori baru berhasil dan tampil di daftar
- [ ] Edit nama/urutan/icon kategori berhasil tersimpan
- [ ] Hapus kategori berhasil (baris hilang dari sheet CATEGORIES)

## Kegiatan & QR Code
- [ ] Tambah kegiatan baru berhasil, QR Code otomatis tampil
- [ ] Link kegiatan berbentuk `...exec?activity=ACT-XXXXXXXX` dan bisa disalin
- [ ] Tombol "Bagikan via WhatsApp" membuka wa.me dengan pesan terisi
- [ ] Tombol "Bagikan via Email" membuka aplikasi email dengan draft terisi
- [ ] QR Code bisa diunduh sebagai gambar PNG
- [ ] Membuka QR Code dari HP lain (scan kamera) mengarah ke halaman absensi kegiatan yang benar

## Absensi via QR (Peserta, tanpa login)
- [ ] Scan QR membuka form 4 langkah: Data Diri → Kehadiran → Infak → Tanda Tangan
- [ ] Waktu datang otomatis tercatat sesuai zona waktu perangkat
- [ ] Tanda tangan bisa digambar, dihapus, dan disimpan
- [ ] Submit absensi menampilkan halaman "Absensi Berhasil Disimpan" + teks Arab
- [ ] Data baru muncul di sheet `ATTENDANCE` pada Google Spreadsheet
- [ ] Mencoba absen kedua kali dengan nama sama pada kegiatan sama → ditolak dengan pesan "Anda sudah melakukan absensi pada kegiatan ini"

## Absensi Manual (Admin/Operator)
- [ ] Buka Kegiatan → Absen Manual → isi form → simpan → data masuk ke daftar hadir
- [ ] Nomor urut otomatis berlanjut dengan benar (tidak bentrok dengan data QR)

## Infak
- [ ] Infak yang diisi lewat form QR tersimpan terpisah di sheet `INFAK` (bukan tercampur di ATTENDANCE)
- [ ] Halaman Infak menampilkan total infak yang benar

## Laporan & Export
- [ ] Halaman Laporan bisa difilter per kegiatan/kategori/tanggal/status kehadiran
- [ ] Export Excel dari halaman Laporan menghasilkan file `.xlsx` yang bisa dibuka
- [ ] Export Excel dari detail kegiatan berhasil
- [ ] Export Word (.doc) menghasilkan dokumen dengan kop surat & tabel peserta
- [ ] Export PDF menghasilkan dokumen dengan logo, identitas organisasi, tabel peserta (otomatis berpindah halaman jika peserta banyak), area tanda tangan penanggung jawab, dan area stempel basah kosong

## Pengaturan (Identitas Aplikasi)
- [ ] Ganti nama organisasi/masjid/alamat/warna tema tersimpan dan langsung terlihat di halaman login & dashboard
- [ ] Logo (URL gambar) tampil di halaman login setelah disimpan

## Pengguna & Role
- [ ] Administrator bisa membuat akun Operator baru
- [ ] Login sebagai Operator: menu Pengaturan & Pengguna TIDAK muncul
- [ ] Operator tetap bisa kelola kegiatan, peserta, dan absensi

## Migrasi Data Lama
- [ ] Tempel JSON contoh di kolom migrasi → klik migrasi → data baru muncul di Spreadsheet

## Ketahanan & Keamanan
- [ ] Mematikan koneksi internet saat submit absensi → muncul pesan "Koneksi internet terputus..."
- [ ] Membuka link kegiatan yang sudah dihapus/nonaktif → muncul pesan "Kegiatan tidak ditemukan"
- [ ] Dua perangkat mengisi absensi pada kegiatan yang sama secara bersamaan → nomor urut tidak bentrok/tertimpa
