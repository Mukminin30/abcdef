# Daftar Hadir Pengajian — Real Database Google Spreadsheet

Paket ini berisi konversi lengkap aplikasi Daftar Hadir/Absensi Pengajian
dari database lokal browser (localStorage/IndexedDB) menjadi aplikasi
dengan **Google Spreadsheet sebagai database utama** dan **Google Apps
Script sebagai backend/API**, dengan frontend tetap satu file `index.html`.

## Isi Paket

| File | Fungsi |
|---|---|
| `Code.gs` | Backend lengkap — Google Apps Script (API, autentikasi, validasi, QR, dsb) |
| `index.html` | Frontend lengkap — satu file (HTML+CSS+JS), mobile-first, sesuai desain |
| `SETUP_GUIDE.md` | **Mulai dari sini.** Panduan setup langkah demi langkah untuk pengguna awam |
| `TESTING_CHECKLIST.md` | Daftar uji coba setelah deployment |
| `TROUBLESHOOTING.md` | Solusi masalah umum (CORS, QR tidak terbuka, dsb) |

## Mulai Cepat

1. Baca **`SETUP_GUIDE.md`** dan ikuti dari Bagian A sampai F (± 15-20 menit).
2. Setelah selesai, jalankan seluruh item di **`TESTING_CHECKLIST.md`**.
3. Jika ada kendala, cek **`TROUBLESHOOTING.md`**.

## Fitur Utama

- **Database:** Google Spreadsheet (8 sheet: SETTINGS, USERS, CATEGORIES,
  ACTIVITIES, PARTICIPANTS, ATTENDANCE, INFAK, SIGNATURES).
- **Login & Role:** Administrator, Operator, Peserta.
- **Kategori & Kegiatan:** CRUD lengkap, dapat dikelola bebas.
- **1 Kegiatan = 1 QR Code = 1 Link unik**, dapat dibagikan via WhatsApp/Email.
- **Absensi QR (4 langkah):** Data Diri → Kehadiran → Infak → Tanda Tangan.
- **Absensi manual** oleh Admin/Operator.
- **Anti absensi ganda** — divalidasi ulang di server (bukan cuma di frontend).
- **Infak** tersimpan di sheet terpisah, tidak tercampur status kehadiran.
- **Dashboard & Laporan** dengan filter lengkap.
- **Export PDF resmi** (kop surat, logo, tabel otomatis berpindah halaman,
  area tanda tangan penanggung jawab, area stempel basah kosong),
  **Export Word (.doc)**, **Export Excel (.xlsx)**.
- **Istilah "Dapukan"** dan kalimat resmi berbahasa Arab dipertahankan sesuai
  permintaan, tidak diubah menjadi "Jabatan"/"Assalamu'alaikum"/"Terima Kasih".
- **LockService** mencegah data tertimpa saat banyak peserta absen bersamaan.
- **Migrasi data lama** dari localStorage ke Google Spreadsheet (jika ada).

## Dependency (CDN) yang Digunakan di `index.html`

Semua dimuat otomatis via CDN saat halaman dibuka (butuh koneksi internet):

- `cdn.tailwindcss.com` — styling
- `fonts.googleapis.com` — font Inter & Amiri (untuk teks Arab)
- `qrcodejs` (jsdelivr) — pembuatan QR Code
- `signature_pad` (jsdelivr) — tanda tangan digital
- `xlsx` / SheetJS (jsdelivr) — export Excel
- `jspdf` + `jspdf-autotable` (jsdelivr) — export PDF resmi
- `lucide` (unpkg) — ikon

## Catatan Arsitektur Penting

- **Google Spreadsheet adalah satu-satunya sumber data (source of truth).**
  `localStorage` di browser hanya dipakai untuk token sesi login — bukan
  database.
- Backend memvalidasi ulang **semua** input (bukan hanya percaya validasi
  JavaScript di frontend), termasuk deteksi absensi ganda dan token QR.
- Frontend dan backend berjalan dari **satu deployment Apps Script yang
  sama** secara default (tidak perlu hosting terpisah), tapi tetap bisa
  di-hosting terpisah jika diinginkan — lihat `SETUP_GUIDE.md` Bagian G.

Selamat menggunakan. الْحَمْدُ لِلّٰهِ جَزَاكُمُ اللّٰهُ خَيْرًا
